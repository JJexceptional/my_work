package com.example.e_commerce.model;

import java.util.HashSet;
import java.util.Set;

public class Order {

    public static Set<Integer> items_id = new HashSet<>();
}
