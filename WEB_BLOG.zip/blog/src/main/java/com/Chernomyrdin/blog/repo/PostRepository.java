package com.Chernomyrdin.blog.repo;

import com.Chernomyrdin.blog.models.Post;
import org.springframework.data.repository.CrudRepository;

public interface PostRepository extends CrudRepository<Post, Long> {

}
